//
//  main.cpp
//  Snowman
//
//  Created by 吳立凱 on 2021/11/9.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
