//
//  main.hpp
//  testing
//
//  Created by 吳立凱 on 2021/11/13.
//

#ifndef main_hpp
#define main_hpp

#include <stdio.h>

#endif /* main_hpp */
