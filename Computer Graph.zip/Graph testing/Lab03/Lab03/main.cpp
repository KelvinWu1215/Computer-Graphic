#define GL_SILENCE_DEPRECATION
#include "GL/glew.h"
#include "OpenGL/OpenGL.h"
#include "GLUT/glut.h"
#include <stdio.h>
#define GLUT_DISABLE_ATEXIT_HACK
#include <math.h>

#define PI 3.14159  //设置圆周率

int R = 10;

GLfloat AngleX;
GLfloat AngleY;
float theta = 0.0;  //旋转初始角度值
void snowMan(){
    
    
    
    glutSolidSphere(0.6, 80, 80);

    glTranslatef(0, -1.4, 0);
    glutSolidSphere(0.80, 80, 80);
    
    glTranslatef(0, -1.8, 0);
    glutSolidSphere(1.0, 80, 80);

    glColor3f(1, 1, 1);
    glLoadIdentity();
    glPopMatrix();
    glPushMatrix();

    glTranslatef(-1.0,-0.7, 0);
    glRotatef(45, 0, 0, 1);
    glScalef(1, 8, 1);
    glutSolidCube(0.1);

    glLoadIdentity();
    glPopMatrix();
    glPushMatrix();

    glTranslatef(1.0, -0.7, 0);
    glRotatef(-45, 0, 0, 1);
    glScalef(1, 8, 1);
    glutSolidCube(0.1);

    glLoadIdentity();
    glPopMatrix();
    glPushMatrix();

    glTranslatef(-1.3, -0.4, 0);
    glRotatef(-45, 0, 0, 1);
    glScalef(1, 3, 1);
    glutSolidCube(0.1);

    glLoadIdentity();
    glPopMatrix();
    glPushMatrix();

    glTranslatef(1.3, -0.4, 0);
    glRotatef(45, 0, 0, 1);
    glScalef(1, 3, 1);
    glutSolidCube(0.1);
    
    glLoadIdentity();
}

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    snowMan();
    
    
    glutSwapBuffers();
    
}
void myidle()
{
    theta += 1.0;   //旋转角度增加1度
    if (theta >= 2 * PI) {
        theta -= 2 * PI;   //如果旋转角度大于360度，则复原
    }
        
 
 
    glutPostRedisplay();  //重画，相当于重新调用Display(),改编后的变量得以传给绘制函数
}

void reshape(int w, int h)
{
    GLfloat aspect = (GLfloat)w / (GLfloat)h;
    GLfloat nRange = 2.0f;
    glViewport(0,0,w,h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    if (w<=h)
    {   glOrtho(-nRange, nRange, -nRange * aspect, nRange * aspect, -nRange, nRange);  }
    else
    {  glOrtho(-nRange, nRange, -nRange / aspect, nRange / aspect, -nRange, nRange);  }
    glFrustum(-1, 1, -1, 1, 1.5, 20);
    gluLookAt(1, 0, 8, 1, 0, -1, 0, 1, 0);
}
 
void init()
{
    AngleX = 30.0f;
    AngleY = -45.0f;
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_DITHER);
    glShadeModel(GL_SMOOTH);
}

int main(int argc,char* argv[])
{
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500,500);
    glutCreateWindow("Snowman");
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMainLoop();
}
