#ifndef __Snowman__
#define __Snowman__

#define _USE_MATH_DEFINES
#include "DisplayableObject.h"
#include "Animation.h"
#include <cmath>
#include <string>
#include <vector>

class Snowman :
    public DisplayableObject,
    public Animation
{
public:
    Snowman();
    ~Snowman();
    void display();
    void update(float dT);

private:
    float animationTime;
    float nangle, aT, aS;

    void drawSnowman();
    void drawDown();
    void drawMid();
    void drawUp();
};

#endif


