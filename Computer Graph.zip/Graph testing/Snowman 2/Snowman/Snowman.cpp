#include "Snowman.h"
#define GL_SILENCE_DEPRECATION
#include "GL/glew.h"
#include "OpenGL/OpenGL.h"
#include "GLUT/glut.h"
#include <stdio.h>
#define GLUT_DISABLE_ATEXIT_HACK
#include <math.h>

Snowman::Snowman() :
    animationTime(10.0f), nangle(0.f), aS(0.f)
{
}

void Snowman::update(float dT)
{
    aT = fmod(aT + dT, animationTime);
    aS = 10.f * aT / animationTime;
    nangle = 36.0* aS;//rotate angle
}

void Snowman::display()
{
    glPushMatrix();
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glColor3f(1.f, 1.f, 1.f);
    glTranslatef(pos[0], pos[1], pos[2]);
    glScalef(scale[0], scale[1], scale[2]);
    drawSnowman();
    glPopAttrib();
    glPopMatrix();
}

void Snowman::drawSnowman()
{
    glPushMatrix();// original
    glRotatef(nangle, 0.f, 1.f, 0.f);
    float size_snow;
    if (aS < 5) {
        size_snow = -0.1 * aS + 1;
    }
    else {
        size_snow = 0.1 * aS;
    }
    glScalef(size_snow, size_snow, size_snow);
    drawDown();
    drawMid();
    drawUp();
    glPopMatrix();
}

void Snowman::drawDown()
{
    //draw a sphere which represents the legs
    glTranslatef(-4.f, 2.f, 0.f);
    glutSolidSphere(2, 50, 50);
}

void Snowman::drawMid()
{
    glTranslatef(0.f, 3.6f, 0.f);
    glRotated(-90, 0.f, 1.f, 0.f);
    glPushMatrix();
    glutSolidSphere(1.6, 50, 50); //draw a sphere which represents the body
    //draw the left arm
    glRotatef(50, 0, 0, 1);
    glTranslatef(0.0f, 3.0f, 0.0f);
    glScalef(.2f, 1.f, 0.2f);
    glutWireCube(2.8);
    //draw the left hand.
    glTranslatef(0.0f, 1.8f, 0.0f);
    glScalef(5.f, 1.f, 5.f);
    glutWireCube(0.8);
    glPopMatrix();
    glPushMatrix();
    //draw the right arm and hand
    glRotatef(-50, 0, 0, 1);
    glTranslatef(0.0f, 3.0f, 0.0f);
    glScalef(.2f, 1.f, 0.2f);
    glutWireCube(2.8);
    //draw the right hand.
    glTranslatef(0.0f, 1.8f, 0.0f);
    glScalef(5.f, 1.f, 5.f);
    glutWireCube(0.8);
    glPopMatrix();
}

void Snowman::drawUp()
{
    /*
    * draw a sphere which represents the head.
    */
    glTranslatef(0.f, 2.8f, 0.f);
    glutSolidSphere(1.2f, 50, 50);
    glPushMatrix();
    /*
    * draw the eyes
    */
    glRotatef(40, 0.f, 1.f, 1.f);
    glTranslatef(0.0f, -0.2f, -1.2f);
    glColor3f(0.0f,0.0f, 0.0f); //the color of eyes is black.
    glutSolidSphere(0.1f, 40, 50);
    glPopMatrix();
    glRotatef(-40, 0.f, 1.f, 1.f);
    glTranslatef(0.0f, -0.2f, -1.2f);
    glColor3f(0.0f, 0.0f, 0.0f);
    glutSolidSphere(0.1f, 40, 50);
}
Snowman::~Snowman()
{
}
