#ifndef __Animation__
#define __Animation__
using namespace std;
class Animation
{

public:
    virtual void update(float dT) = 0;
};

#endif
